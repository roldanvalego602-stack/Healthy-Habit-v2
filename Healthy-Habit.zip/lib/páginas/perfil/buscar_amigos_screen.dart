import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:healthy_habit/p%C3%A1ginas/perfil/perfil_muestra.dart';

import 'amigos_servicio.dart';
import '../../Contenido_del_tema/colores.dart';
import '../../Contenido_del_tema/chip_recompensa.dart';

class BuscarAmigosScreen extends StatefulWidget {
  const BuscarAmigosScreen({super.key});

  @override
  State<BuscarAmigosScreen> createState() => _BuscarAmigosScreenState();
}

class _BuscarAmigosScreenState extends State<BuscarAmigosScreen> {
  final TextEditingController _searchController = TextEditingController();

  String _terminoBusqueda = '';

  Set<String> _siguiendo = {};
  Set<String> _pendientes = {};
  final Set<String> _ocupados = {};
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _siguiendoSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _enviadasSub;

  FirebaseFirestore get _db =>
      FirebaseFirestore.instanceFor(app: Firebase.app(), databaseId: 'default');

  @override
  void initState() {
    super.initState();

    final miUid = AmigosServicio.uidActual;
    if (miUid != null) {
      _siguiendoSub = AmigosServicio.siguiendo(miUid).listen((snap) {
        if (!mounted) return;
        setState(() => _siguiendo = snap.docs.map((d) => d.id).toSet());
      });
      _enviadasSub = AmigosServicio.solicitudesEnviadas(miUid).listen((snap) {
        if (!mounted) return;
        setState(() => _pendientes = snap.docs.map((d) => d.id).toSet());
      });
    }

    _searchController.addListener(() {
      if (!mounted) return;

      setState(() {
        _terminoBusqueda = _searchController.text.trim().toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    _siguiendoSub?.cancel();
    _enviadasSub?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  String _texto(dynamic valor, [String predeterminado = '']) {
    if (valor == null) return predeterminado;

    final texto = valor.toString().trim();
    return texto.isEmpty ? predeterminado : texto;
  }

  int _numero(dynamic valor, [int predeterminado = 0]) {
    if (valor is int) return valor;
    if (valor is num) return valor.toInt();

    return int.tryParse(valor?.toString() ?? '') ?? predeterminado;
  }

  String _username(Map<String, dynamic> datos) {
    final username = _texto(datos['username'], 'usuario');
    return username.startsWith('@') ? username : '@$username';
  }

  bool _coincide(Map<String, dynamic> datos) {
    if (_terminoBusqueda.isEmpty) return true;

    final nombre = _texto(datos['name']).toLowerCase();
    final username = _texto(datos['username']).toLowerCase();
    final usernameConArroba = '@$username';

    return nombre.contains(_terminoBusqueda) ||
        username.contains(_terminoBusqueda) ||
        usernameConArroba.contains(_terminoBusqueda);
  }

  /// Envía o cancela una solicitud; si ya se sigue a la persona, deja de
  /// seguirla directamente (sin necesidad de solicitud para dejar de seguir).
  Future<void> _alternarSeguir(String uid, String nombre) async {
    if (_ocupados.contains(uid)) return;

    final yaSigue = _siguiendo.contains(uid);
    final pendiente = _pendientes.contains(uid);
    setState(() => _ocupados.add(uid));

    try {
      String mensaje;
      if (yaSigue) {
        await AmigosServicio.dejarDeSeguir(uid);
        mensaje = 'Dejaste de seguir a $nombre';
      } else if (pendiente) {
        await AmigosServicio.cancelarSolicitud(uid);
        mensaje = 'Cancelaste la solicitud a $nombre';
      } else {
        await AmigosServicio.enviarSolicitud(uid);
        mensaje = 'Solicitud enviada a $nombre';
      }
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(mensaje)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo completar la acción: $e')),
      );
    } finally {
      if (mounted) setState(() => _ocupados.remove(uid));
    }
  }

  Widget _botonSeguir(String uid, String nombre) {
    final siguiendo = _siguiendo.contains(uid);
    final pendiente = _pendientes.contains(uid);
    final ocupado = _ocupados.contains(uid);

    final String etiqueta =
        siguiendo ? 'Siguiendo' : (pendiente ? 'Pendiente' : 'Seguir');
    final Color colorTexto =
        siguiendo
            ? AppColores.verdePrincipal
            : (pendiente ? const Color(0xFFB8860B) : AppColores.verdeOscuro);
    final Color colorBorde =
        siguiendo
            ? AppColores.verdePrincipal
            : (pendiente ? const Color(0xFFD5A33E) : AppColores.verdeMenta);

    return GestureDetector(
      onTap: () => _alternarSeguir(uid, nombre),
      child: Container(
        height: 36,
        constraints: const BoxConstraints(minWidth: 92),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: (siguiendo || pendiente) ? Colors.white : AppColores.verdeMenta,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: colorBorde, width: 1.4),
        ),
        child:
            ocupado
                ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColores.verdePrincipal,
                  ),
                )
                : Text(
                  etiqueta,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: colorTexto,
                  ),
                ),
      ),
    );
  }

  void _abrirPerfil(Map<String, dynamic> datos, String uid) {
    final nombre = _texto(datos['name'], 'Usuario');
    final username = _username(datos);
    final nivel = _numero(datos['level'], 1);
    final racha = _numero(datos['currentStreak'], 0);

    // El perfil público existente recibe completedHabits.
    // Este campo se usa si existe en el documento de Firestore.
    final habitosCompletados = _numero(datos['completedHabits'], 0);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => PublicProfileScreen(
              userId: uid,
              name: nombre,
              username: username,
              level: nivel,
              streakDays: racha,
              completedHabits: habitosCompletados,
            ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final usuarioActual = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: AppColores.fondoClaro,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColores.textoOscuro),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Buscar Amigos',
          style: TextStyle(
            color: AppColores.textoOscuro,
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Buscar por usuario o nombre...',
                  hintStyle: TextStyle(
                    color: AppColores.textoGris,
                    fontSize: 14,
                  ),
                  prefixIcon: Icon(Icons.search, color: AppColores.textoGris),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Sugerencias de la comunidad',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: AppColores.textoOscuro,
              ),
            ),
            const SizedBox(height: 14),
            Expanded(
              child:
                  usuarioActual == null
                      ? const Center(
                        child: Text('Inicia sesión para buscar amigos.'),
                      )
                      : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                        stream: _db.collection('users').snapshots(),
                        builder: (context, snapshot) {
                          if (snapshot.hasError) {
                            return const Center(
                              child: Text(
                                'No se pudieron cargar los usuarios. '
                                'Verifica las reglas de Firestore.',
                                textAlign: TextAlign.center,
                              ),
                            );
                          }

                          if (snapshot.connectionState ==
                                  ConnectionState.waiting &&
                              !snapshot.hasData) {
                            return const Center(
                              child: CircularProgressIndicator(
                                color: AppColores.verdePrincipal,
                              ),
                            );
                          }

                          final documentos = snapshot.data?.docs ?? [];

                          final usuarios =
                              documentos.where((documento) {
                                if (documento.id == usuarioActual.uid) {
                                  return false;
                                }

                                return _coincide(documento.data());
                              }).toList();

                          if (usuarios.isEmpty) {
                            return Center(
                              child: Text(
                                _terminoBusqueda.isEmpty
                                    ? 'Todavía no hay otros usuarios registrados.'
                                    : 'No se encontraron usuarios.',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: AppColores.textoGris,
                                  fontSize: 14,
                                ),
                              ),
                            );
                          }

                          return ListView.separated(
                            itemCount: usuarios.length,
                            separatorBuilder:
                                (context, index) => const SizedBox(height: 12),
                            itemBuilder: (context, index) {
                              final documento = usuarios[index];
                              final datos = documento.data();
                              final uid = documento.id;

                              final nombre = _texto(datos['name'], 'Usuario');
                              final username = _username(datos);
                              final nivel = _numero(datos['level'], 1);
                              final racha = _numero(datos['currentStreak'], 0);

                              return Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: AppColores.bordeGris,
                                    width: 1,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const CircleAvatar(
                                      radius: 24,
                                      backgroundColor: AppColores.verdeMenta,
                                      child: Icon(
                                        Icons.person_rounded,
                                        color: AppColores.verdeOscuro,
                                        size: 28,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            nombre,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w800,
                                              fontSize: 15,
                                              color: AppColores.textoOscuro,
                                            ),
                                          ),
                                          Text(
                                            username,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: AppColores.textoGris,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Wrap(
                                            spacing: 6,
                                            runSpacing: 4,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.center,
                                            children: [
                                              ChipRecompensa(
                                                texto: 'Nivel $nivel',
                                                colorFondo:
                                                    AppColores.verdeMenta,
                                                colorTexto:
                                                    AppColores.verdeOscuro,
                                              ),
                                              Text(
                                                '$racha días 🔥',
                                                style: const TextStyle(
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      tooltip: 'Ver perfil',
                                      onPressed: () => _abrirPerfil(datos, uid),
                                      icon: const Icon(
                                        Icons.account_circle_outlined,
                                        color: AppColores.textoGris,
                                      ),
                                    ),
                                    _botonSeguir(uid, nombre),
                                  ],
                                ),
                              );
                            },
                          );
                        },
                      ),
            ),
          ],
        ),
      ),
    );
  }
}
